import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public interface Metod{
    void addImage(ImageIcon image, Point point, boolean addTextField);
    void clearPanel();
   void runCode();
}
